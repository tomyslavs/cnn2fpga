#include <stdio.h>
#include <string.h>
#include <stdlib.h>     /* strtol */
#include <xil_io.h>
#include "xil_printf.h"
#include "xscugic.h"
#include "ps7_init.h"
#include "xparameters.h"
#include "platform.h"
#include "lwip/err.h"
#include "lwip/tcp.h"

// definitions
#define print_enabled 		0
#define FC1_to_DDR_enabled 	0
//#define IMG_BASE 			0x10000000
//#define NET_BASE			0x10800000
//#define INSTR_BASE			0x10801000
//#define CORE_BASE			0x10900000
//#define FC_W_BASE[0]		0x10902000
//#define FC_W_BASE[1]		0x10982000
//#define FC_B_BASE[0]		0x10984000
//#define FC_B_BASE[1]		0x10985000
//#define TEMP_BASE			0x10986000
//#define RES_BASE			0x11F00000
//#define N_CONV_INSTR		2
//#define FC1_DATA_BASE		0x10986000

//#define FSBL_DEBUG // paste to main.c in fsbl project
#define DDR_BASE			0x10000000 	// total: 512MB (0x00000000 - 0x1FFFFFFF)
#define DDR_BASE0			0x10200000 	// total: 512MB (0x00000000 - 0x1FFFFFFF)
#define DDR_BASE1			0x10400000 	// total: 512MB (0x00000000 - 0x1FFFFFFF)
#define DDR_BASE2			0x10600000 	// total: 512MB (0x00000000 - 0x1FFFFFFF)
#define DDR_BASE3			0x10800000 	// total: 512MB (0x00000000 - 0x1FFFFFFF)
#define DDR_BASE4			0x10A00000	// weights
//#define DDR_BASE_IMAGE		0x10C00000	// input image
#define DDR_RANGE			0x06000000
#define X					64	//64
#define Y					64	//48
#define PACKET_SIZE_TX 		X*Y*4*2   // X * Y * CH/DMA * Bytes/sample		1024*1024*1 = 1MB = 0x00100000
#define PACKET_SIZE_RX 		PACKET_SIZE_TX/4 // /4 if max pool, else /1
#define PACKET_SIZE_WEIGHT	512*1 // weight packet size, 512B/core x 16 core config
#define TOTAL_PACKETS 1
#define CLEAN_BYTES		64*1024 	// 64KB
#define CONV_CFG_LEN	32*16		// 32 rows * 8CH*2B

// net_cfg (IP/TCP)

void disp_cmd0(u32 name);
void disp_DDR_2(u32 base, u32 nuo, u32 length);
u32 check_cmd0(char *recv_buf);
int num_of_parameters(char *str, u16 RECV_BUF_SIZE);
void decode_param_from_LabView(char *recv_buf, u16 RECV_BUF_SIZE);
void packet2ddr(char *recv_buf, u16 RECV_BUF_SIZE);
u16 check_preamble(char *recv_buf, u16 RECV_BUF_SIZE);
void clean_ram(u32 BASE, u32 NumBytes);
void reset_net_config();
u32 process_packet(char * recv_buf, u16 RECV_BUF_SIZE, u16 RECV_BUF_SIZE_TOT);
void decode_net_config();
u32 get_conv_cfgs(u32 in, u32 out);
u32 get_sum_cfgs(u32 in, u32 out);
void send_image(struct tcp_pcb *pcb, const void *arg, u32 len, u8_t apiflags);

// AXI DMA (Conv core)
void arm_tic(u32 init);
u32 arm_toc();
void arm_set_precision(u32 val);
void time_print(u32 timer);
void arm_enable_mm2s_tready(u32 val);
void arm_delay_conv_valid0_start(u32 val);
void arm_delay_conv_valid1_start(u32 val);
void arm_delay_conv_valid0_done(u32 val);
void arm_delay_conv_valid1_done(u32 val);
void arm_delay_border_pix_deny_start(u32 val);
void arm_x_max(u32 val);
void arm_y_max(u32 val);
void arm_B(u32 val);
void arm_ka(u32 val);
void arm_be(u32 val);
void arm_update_weights(u32 val);
void arm_enable_filter(u32 val);
void arm_relu_or_pool(u32 val);
void wait_ms(u32 kiek);
void wait_us(u32 kiek);
void wait_100ns(u32 kiek);
void disp_DDR(u32 nuo, u32 length);
void FillDDR(u32 addr, u32 length, u32 data);
int SetUpInterruptSystem(XScuGic *XScuGicInstancePtr);
void InitAXIDMA_2_s2mm(u32 reg_val);
void StartTransferDMA_2_s2mm(u32 dstAddress, u32 len);
void InterruptHandler_2_s2mm();
u32 InitInterruptSystem_2_s2mm(u16 DeviceID);
void InitAXIDMA_0_mm2s(u32 reg_val);
void StartTransferDMA_0_mm2s(u32 dstAddress, u32 len);
void InterruptHandler_0_mm2s();
u32 InitInterruptSystem_0_mm2s(u16 DeviceID);
void InitAXIDMA_3_s2mm(u32 reg_val);
void StartTransferDMA_3_s2mm(u32 dstAddress, u32 len);
void InterruptHandler_3_s2mm();
u32 InitInterruptSystem_3_s2mm(u16 DeviceID);
void InitAXIDMA_1_mm2s(u32 reg_val);
void StartTransferDMA_1_mm2s(u32 dstAddress, u32 len);
void InterruptHandler_1_mm2s();
u32 InitInterruptSystem_1_mm2s(u16 DeviceID);
void call_cnn();
void read_instruction(u32 i);
void run_instruction();
void arm_set_conv_timming();
void run_conv_core(u32 conv_or_sum, u32 xn_relu_pool);
void set_fc_b(u32 layer, u32 src, u32 size);
