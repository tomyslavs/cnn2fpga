#include "_app.h"

// global variables
u32 param[1024]={0}, EoS=0, send_to_pc=0; // EOS-end of stream
u32 kiek_param=0, cmd0=0, last_cmd0=0, len=0, addr_shift=0, addr_image_shift=0, net_config_in_ddr=0, shift_preamble;
u32 num_layers, input_resolution[3], ch_in_conv[20], ch_out_conv[20], ch_in_fc[5], ch_out_fc[5];
u32 fc1_in_max, fc1_max, fc2_max, fc1_in_mem_updates;
u32 conv_idx, bn_idx, relu_idx, pool_idx, fc_idx, conv_cfgs[20], sum_cfgs[20], conv_and_sum_cfgs[20], all_conv_len, all_fc_w_len, all_fc_b_len;
u32 IMG_BASE, NET_BASE, INSTR_BASE, CORE_BASE, FC_W_BASE[5], FC_B_BASE[5], TEMP_BASE, RES_BASE, N_CONV_INSTR, FC1_DATA_BASE;
//u32 FC_W_BASE[2]={0x10902000,0x10982000}, FC_B_BASE[2]={0x10984000,0x10985000};
u32 instr0, yx_lim, current_layer_idx, sizeTX, sizeRX, src_0, src_1, dst_0, dst_1;
extern u32 timer0, timer1, timer2, timer3;

// functions
u32 process_packet(char * recv_buf, u16 RECV_BUF_SIZE, u16 RECV_BUF_SIZE_TOT){
//	int i=0;
//	for (i=0;i<RECV_BUF_SIZE;i++)
//		xil_printf("%x\n\r", recv_buf[i]);
//	disp_DDR(DDR_BASE, 16);
	RECV_BUF_SIZE = check_preamble(recv_buf, RECV_BUF_SIZE);
	packet2ddr(recv_buf, RECV_BUF_SIZE);
//	Xil_DCacheFlushRange(DDR_BASE, DDR_RANGE); // --------------------------------------
//	disp_DDR_2(DDR_BASE, addr_shift-RECV_BUF_SIZE, RECV_BUF_SIZE); // display only current packet placed in ddr
	decode_net_config(); // if net-config arrived!

//	u32 *ptrDDR = DDR_BASE;
//	decode_param_from_LabView(*ptrDDR, RECV_BUF_SIZE);
//	xil_printf("decode_param done\r\n");
//	for (i=0;i<kiek_param;i++)
//		xil_printf("0x%08x, %d\n\r", param[i], param[i]);

//	decode_param_from_LabView(recv_buf,RECV_BUF_SIZE);
//	cmd0=check_cmd0(recv_buf);

//	if (cmd0==0x02){
//		decode_net_config();
//	}
//	disp_cmd0(cmd0);

//	int i=0;
//	for (i=0;i<kiek_param;i++)
//		xil_printf("0x%08x, %d\n\r", param[i], param[i]);
	last_cmd0 = cmd0;
	return send_to_pc;
}

u16 check_preamble(char *recv_buf, u16 RECV_BUF_SIZE){
	u32 i, cnt=0;
	send_to_pc = 0;
	EoS = 0;
	if (RECV_BUF_SIZE > 64){
		for(i=0; i<64; i++){
			if (recv_buf[i]==0xFF)
				cnt++;
		}
		if (cnt==64){ // if preamble is detected, else keep previous cmd0 until EoS arrives
			addr_shift = 0; // reset ddr addr shift
			shift_preamble = 64 + 8;
			len = (recv_buf[71]<<24) + (recv_buf[70]<<16) + (recv_buf[69]<<8) + (recv_buf[68]); // for 32b data
			cmd0=recv_buf[64];
//			xil_printf("CMD0 = 0x%08x",cmd0);
//			xil_printf("\r\n");
			switch(cmd0){
				case 0x01 : // Image
					xil_printf("\r\ncmd0=0x%02x image, len=%d",cmd0,len);
//					addr_image_shift = 0; // reset image addr shift
					break;
				case 0x09 : // Base addresses
					xil_printf("\r\ncmd0=0x%02x Base addresses, len=%d\r\n",cmd0,len);
					IMG_BASE =		(recv_buf[75] <<24) + (recv_buf[74] <<16) + (recv_buf[73] <<8) + (recv_buf[72]); // 4B
					NET_BASE =		(recv_buf[79] <<24) + (recv_buf[78] <<16) + (recv_buf[77] <<8) + (recv_buf[76]); // 4B
					INSTR_BASE =	(recv_buf[83] <<24) + (recv_buf[82] <<16) + (recv_buf[81] <<8) + (recv_buf[80]); // 4B
					CORE_BASE =		(recv_buf[87] <<24) + (recv_buf[86] <<16) + (recv_buf[85] <<8) + (recv_buf[84]); // 4B
					FC_W_BASE[0] =	(recv_buf[91] <<24) + (recv_buf[90] <<16) + (recv_buf[89] <<8) + (recv_buf[88]); // 4B
					FC_W_BASE[1] =	(recv_buf[95] <<24) + (recv_buf[94] <<16) + (recv_buf[93] <<8) + (recv_buf[92]); // 4B
					FC_B_BASE[0] =	(recv_buf[99] <<24) + (recv_buf[98] <<16) + (recv_buf[97] <<8) + (recv_buf[96]); // 4B
					FC_B_BASE[1] =	(recv_buf[103]<<24) + (recv_buf[102]<<16) + (recv_buf[101]<<8) + (recv_buf[100]); // 4B
					TEMP_BASE =		(recv_buf[107]<<24) + (recv_buf[106]<<16) + (recv_buf[105]<<8) + (recv_buf[104]); // 4B
					RES_BASE = 		(recv_buf[111]<<24) + (recv_buf[110]<<16) + (recv_buf[109]<<8) + (recv_buf[108]); // 4B
					N_CONV_INSTR = 	(recv_buf[115]<<24) + (recv_buf[114]<<16) + (recv_buf[113]<<8) + (recv_buf[112]); // 4B
					FC1_DATA_BASE = (recv_buf[119]<<24) + (recv_buf[118]<<16) + (recv_buf[117]<<8) + (recv_buf[116]); // 4B

					xil_printf("IMG_BASE=0x%08x\r\n",IMG_BASE);
					xil_printf("NET_BASE=0x%08x\r\n",NET_BASE);
					xil_printf("INSTR_BASE=0x%08x\r\n",INSTR_BASE);
					xil_printf("CORE_BASE=0x%08x\r\n",CORE_BASE);
					xil_printf("FC_W_BASE[0]=0x%08x\r\n",FC_W_BASE[0]);
					xil_printf("FC_W_BASE[1]=0x%08x\r\n",FC_W_BASE[1]);
					xil_printf("FC_B_BASE[0]=0x%08x\r\n",FC_B_BASE[0]);
					xil_printf("FC_B_BASE[1]=0x%08x\r\n",FC_B_BASE[1]);
					xil_printf("TEMP_BASE=0x%08x\r\n",TEMP_BASE);
					xil_printf("RES_BASE=0x%08x\r\n",RES_BASE);
					xil_printf("N_CONV_INSTR=%d\r\n",N_CONV_INSTR);
					xil_printf("FC1_DATA_BASE=0x%08x\r\n",FC1_DATA_BASE);
					xil_printf("------------------------------------\r\n");
//					FillDDR(IMG_BASE, DDR_RANGE, 0x07000700);
//					Xil_DCacheFlushRange(IMG_BASE, DDR_RANGE);
					wait_ms(100);
					break;
				case 0x02 : // net_config
					xil_printf("\r\ncmd0=0x%02x net_config, len=%d",cmd0,len);
					num_layers = len>>2; // number of rows in net-config.csv
//					addr_shift = 0; // reset ddr addr shift
//					CORE_BASE = len<<2; // in Bytes
//					clean_ram(DDR_BASE, CLEAN_BYTES); // clean memory
					break;
				case 0x08 : // instr_list
					xil_printf("\r\ncmd0=0x%02x instructions, len=%d",cmd0,len);
					break;
				case 0x03 : // conv+bn
					xil_printf("\r\ncmd0=0x%02x conv+bn, len=%d",cmd0,len);
					all_conv_len = len<<1; // count 16b data
//					CORE_BASE = addr_shift+DDR_BASE;
					break;
				case 0x04 : // fc_w
					xil_printf("\r\ncmd0=0x%02x fc_w, len=%d ",cmd0,len);
					all_fc_w_len = len<<1; // count 16b data
//					FC_W_BASE[0] = addr_shift;
					break;
				case 0x05 : // fc_b
					xil_printf("\r\ncmd0=0x%02x fc_b, len=%d ",cmd0,len);
					all_fc_b_len = len<<1; // count 16b data
//					FC_B_BASE[0] = addr_shift;
					break;
				case 0x06 : // ARM print info
					xil_printf("\r\ncmd0=0x%02x disp info, len=%d ",cmd0,len);
//					xil_printf("CORE_BASE=0x%08x(%d)\r\n", CORE_BASE, CORE_BASE);
//					xil_printf("FC_W_BASE[0]=0x%08x(%d), all_fc_w_len=%d\r\n",FC_W_BASE[0],FC_W_BASE[0],all_fc_w_len);
//					xil_printf("FC_W_BASE[1]=0x%08x(%d)\r\n",FC_W_BASE[1],FC_W_BASE[1]);
//					xil_printf("FC_B_BASE[0]=0x%08x(%d), all_fc_b_len=%d\r\n",FC_B_BASE[0],FC_B_BASE[0],all_fc_b_len);
//					xil_printf("FC_B_BASE[1]=0x%08x(%d)\r\n",FC_B_BASE[1],FC_B_BASE[1]);
					disp_DDR_2(NET_BASE, 0, 256*4);
					break;
				case 0x07 : // call_cnn()
					xil_printf("\r\ncmd0=0x%02x call_cnn(), len=%d \r\n",cmd0,len);
					call_cnn();
					send_to_pc = 1; // if call_cnn() then return results to PC
					xil_printf("call_cnn() done\r\n");
					break;
				case 0xFF : // End of Stream
					xil_printf("cmd0=0x%02x end_of_stream, len=%d",cmd0,len);
					EoS = 1;
					break;
				default :
					xil_printf("Not valid cmd0 from PC, len=%d",len);
			}
			xil_printf(", last_cmd0=0x%02x\r\n",last_cmd0);
		}
		else{
			shift_preamble = 0x00;
			xil_printf("."); // next packet received
		}
	}
	else{
		shift_preamble = 0x00;
		xil_printf("."); // next packet received
	}
	return RECV_BUF_SIZE-shift_preamble;
}

void packet2ddr(char *recv_buf, u16 RECV_BUF_SIZE){
	u32 j, NEW_BASE, FLUSH_BASE;
	if 		(cmd0==0x01)	// Image
		NEW_BASE=IMG_BASE;
	else if (cmd0==0x02)	// Net config
		NEW_BASE=NET_BASE;
	else if (cmd0==0x08)	// Instructions
		NEW_BASE=INSTR_BASE;
	else if (cmd0==0x03)	// Conv cfgs
		NEW_BASE=CORE_BASE;
	else if (cmd0==0x04)	// FC w
		NEW_BASE=FC_W_BASE[0];
	else if (cmd0==0x05)	// FC b
		NEW_BASE=FC_B_BASE[0];
	if (cmd0==0x01 || cmd0==0x02 || cmd0==0x08 || cmd0==0x03 || cmd0==0x04 || cmd0==0x05){ // if image or net-config or instr_list or all_conv_layers or all_fc_w or all_fc_b
		for(j=0; j<RECV_BUF_SIZE; j=j+1){ // store Byte by Byte
			Xil_Out32(NEW_BASE+j+addr_shift, recv_buf[j+shift_preamble]);
		}
		FLUSH_BASE = NEW_BASE + addr_shift;
		addr_shift = addr_shift + RECV_BUF_SIZE; // add addr_shift to each next ip/tcp packet
	}
	Xil_DCacheFlushRange(FLUSH_BASE,RECV_BUF_SIZE); //wait_ms(1);
//	else if (cmd0==0x01){ // if image
//		for(j=0; j<RECV_BUF_SIZE; j=j+1){ // store Byte by Byte
//			Xil_Out32(IMG_BASE+j+addr_image_shift, recv_buf[j+shift_preamble]);
//		}
//		addr_image_shift = addr_image_shift + RECV_BUF_SIZE;
//	}

}

void decode_net_config(){
	u32 i, layer_t;
	if (EoS==1 && last_cmd0==0x02){ // end of stream and net-config arrived
		reset_net_config(); // clean layer counters
		xil_printf("-----------net-config.csv-----------\r\n");
		for(i=0; i<num_layers; i++){ // scan all rows in net-config
			layer_t = Xil_In32(NET_BASE+16*i);
			switch(layer_t){
				case 0x00 : // Input layer
					input_resolution[0]=Xil_In32(NET_BASE+4*1); // y
					input_resolution[1]=Xil_In32(NET_BASE+4*2); // x
					input_resolution[2]=Xil_In32(NET_BASE+4*3); // color channels
					xil_printf("Input\t: %d %d %d", input_resolution[0], input_resolution[1], input_resolution[2]);
					break;
				case 0x01 : // Conv
				case 0x02 : // Batch normalization
				case 0x03 : // Rectified Linear Unit
				case 0x04 : // Max Pooling
					xil_printf("Conv\t%d: ", conv_idx);
					ch_in_conv[conv_idx] = Xil_In32(NET_BASE+16*i+4);
					ch_out_conv[conv_idx] = Xil_In32(NET_BASE+16*i+8);
					xil_printf("%d->%d",ch_in_conv[conv_idx], ch_out_conv[conv_idx]);
					conv_cfgs[conv_idx] = get_conv_cfgs(ch_in_conv[conv_idx], ch_out_conv[conv_idx]);
					xil_printf("\tcore cfg: %d",conv_cfgs[conv_idx]);
					sum_cfgs[conv_idx] = get_sum_cfgs(ch_in_conv[conv_idx], ch_out_conv[conv_idx]);
					xil_printf("\tconv sum cfg: %d",sum_cfgs[conv_idx]);
					conv_and_sum_cfgs[conv_idx] = conv_cfgs[conv_idx] + 2*sum_cfgs[conv_idx];
					xil_printf("\tconv and sum cfg: %d",conv_and_sum_cfgs[conv_idx]);
					conv_idx++;
					if(layer_t>=0x02){ // Batch normalization
						xil_printf("\r\nBN\t%d: ", bn_idx);
						bn_idx++;
					}
					if(layer_t>=0x03){ // Rectified Linear Unit
						xil_printf("\r\nReLU\t%d: ", relu_idx);
						relu_idx++;
					}
					if(layer_t==0x04){ // Max Pooling
						xil_printf("\r\nPool\t%d: ", pool_idx);
						pool_idx++;
						xil_printf("%dx%d",input_resolution[0]>>pool_idx,input_resolution[1]>>pool_idx);
					}
					break;
//				case 0x02 : // Batch normalization
//					xil_printf("BN\t%d: ", bn_idx);
//					bn_idx++;
//					break;
//				case 0x03 : // Rectified Linear Unit
//					xil_printf("ReLU\t%d: ", relu_idx);
//					relu_idx++;
//					break;
//				case 0x04 : // Max Pooling
//					xil_printf("Pool\t%d: ", pool_idx);
//					pool_idx++;
//					xil_printf("%dx%d",input_resolution[0]>>pool_idx,input_resolution[1]>>pool_idx);
//					break;
				case 0x05 : // Fully Connected
					xil_printf("FC\t%d: ", fc_idx);
					ch_in_fc[fc_idx] = Xil_In32(NET_BASE+16*i+4);
					ch_out_fc[fc_idx] = Xil_In32(NET_BASE+16*i+8);
//					FC_BASE[fc_idx] = 4;
//					if (fc_idx==1){ // at 2nd FC layer
//						FC_W_BASE[1] = FC_W_BASE[0]+ch_in_fc[fc_idx-1]*ch_out_fc[fc_idx-1]*2;	// FC_W_BASE[1]+CHin(fc1)*CHout(fc1)*2Bytes/sample
//						FC_B_BASE[1] = FC_B_BASE[0]+ch_out_fc[fc_idx-1]*2;						// FC_B_BASE[1]+CHout(fc1)*2Bytes/sample
//						INSTR_BASE = FC_B_BASE[1]+ch_out_fc[fc_idx]*2;							// FC_B_BASE[1]+ch_out_fc(fc2)*2Bytes/sample
//					}
					xil_printf("%d->%d",ch_in_fc[fc_idx], ch_out_fc[fc_idx]);
					fc_idx++;
					break;
				default :
					xil_printf("Not valid cmd0 from PC, len=%d",len);
			}
			xil_printf("\r\n");
		}
		fc1_max = ch_out_fc[0];	// number of neurons in FC1
		fc2_max = ch_out_fc[1]; // number of neurons in FC2
		if (ch_out_conv[conv_idx-1] % 8 == 0) // no remainder
			fc1_in_mem_updates = (ch_out_conv[conv_idx-1]>>3); 		// last conv channels /8 => how much times fc1 data mem will be updated with CH[0-7] batches, e.g. 32CH/8 => 4 updates
		else
			fc1_in_mem_updates = (ch_out_conv[conv_idx-1]>>3) + 1;	// last conv channels /8 + 1
		fc1_in_max = (u32)(ch_in_fc[0]/ch_out_conv[conv_idx-1]); 	// data input resolution to FC1 layer
		//
//		fc1_max = 24; // min
//		fc2_max = 24; // min
//		fc1_in_max = 16*16;
		//
		xil_printf("Total %d Conv\r\n", conv_idx);
		xil_printf("Total %d BN\r\n", bn_idx);
		xil_printf("Total %d ReLU\r\n", relu_idx);
		xil_printf("Total %d Max Pool\r\n", pool_idx);
		xil_printf("Total %d FC\r\n", fc_idx);
		xil_printf("fc1_in_max %d, fc1_in_mem_updates %d\r\n", fc1_in_max, fc1_in_mem_updates);
		xil_printf("fc1_max %d, fc2_max %d\r\n", fc1_max, fc2_max);
		xil_printf("------------------------------------\r\n");
	}
}

void read_instruction(u32 i){
	instr0 = Xil_In32(INSTR_BASE+8*4*i+4*0);
	current_layer_idx = ((instr0>>16) & 0x0000FFFF);
	instr0 = instr0 & 0x0000FFFF;
	yx_lim = Xil_In32(INSTR_BASE+8*4*i+4*1);
	sizeTX = Xil_In32(INSTR_BASE+8*4*i+4*2);
	sizeRX = Xil_In32(INSTR_BASE+8*4*i+4*3);
	src_0  = Xil_In32(INSTR_BASE+8*4*i+4*4);
	src_1  = Xil_In32(INSTR_BASE+8*4*i+4*5);
	dst_0  = Xil_In32(INSTR_BASE+8*4*i+4*6);
	dst_1  = Xil_In32(INSTR_BASE+8*4*i+4*7);
}

u32 get_conv_cfgs(u32 in, u32 out){
	u32 in_t, out_t;
	in_t = (u32)(in/8);
	out_t = (u32)(out/8);
	if (in%8!=0)
		in_t++;
	if (out%8!=0)
		out_t++;
	return in_t*out_t;
}

u32 get_sum_cfgs(u32 in, u32 out){
	u32 in_t, out_t;
	in_t = (u32)(in/8);
	out_t = (u32)(out/8);
	if (in%8!=0)
		in_t++;
	if (out%8!=0)
		out_t++;
	return (in_t-1)*out_t;
}

void reset_net_config(){
	conv_idx=0; bn_idx=0; relu_idx=0; pool_idx=0; fc_idx=0;
}

void clean_ram(u32 BASE, u32 NumBytes)
{
	u32 j;
	for(j=0; j<NumBytes; j=j+4){
		Xil_Out32(BASE+j,0x00000000);
	}
}

void disp_cmd0(u32 name){
	switch(name){
		case 0x01 : // 0x01
			xil_printf("cmd0=0x01 image frame\r\n");
			break;
		case 0x02 : // 0x02
			xil_printf("cmd0=0x02 net_config\r\n");
			break;
		case 0x03 : // 0x03
			xil_printf("cmd0=0x03 conv + bn\r\n");
			break;
		case 0x04 : // 0x04
			xil_printf("cmd0=0x04 fc\r\n");
			break;
		default :
			xil_printf("Not valid cmd0 from PC!\r\n");
	}
}

void disp_DDR_2(u32 base, u32 nuo, u32 length){
	u32 DataRead3, m;
	for (m=nuo>>2; m < (nuo+length)>>2; m++){ // 128 - 2cmd | 1024 - 16cmd
		DataRead3 = Xil_In32(base+4*m);
		if (m%4==0){
			if (m < 10)
				xil_printf("\n\r   %d: ",m);
			else if (m < 100)
				xil_printf("\n\r  %d: ",m);
			else if (m < 1000)
				xil_printf("\n\r %d: ",m);
			else
				xil_printf("\n\r%d: ",m);
		}
		xil_printf("%08x ",DataRead3);
	}
	xil_printf("\n\r");
}

u32 check_cmd0(char *recv_buf){
	char *pEnd;
	return (u32)strtoul(recv_buf,&pEnd,10);
}

int num_of_parameters(char *str, u16 RECV_BUF_SIZE){ // suskaiciuoja tarpus = # of param
	u16 i, num=0;
	for(i=0; i < RECV_BUF_SIZE; i++) {
	   if(str[i]==' ') {
	       num++;
	   }
	}
	xil_printf("param gauta: ");
	xil_printf("%d\n\r", num);
	return num;
}

void decode_param_from_LabView(char *recv_buf, u16 RECV_BUF_SIZE){
	int i;
	char *pEnd;
	kiek_param = num_of_parameters(recv_buf, RECV_BUF_SIZE);
	param[0] = (u32)strtoul(recv_buf,&pEnd,10);
	for(i=1;i<kiek_param;i++)
		param[i] = (u32)strtoul(pEnd,&pEnd,10);
//	param[i] = (u32)strtol(pEnd,NULL,10); \\ iki 2019-11-18
}

void send_image(struct tcp_pcb *tpcb, const void *arg, u32 len, u8_t apiflags){
	err_t err;
	const u16_t fix_len = 1024;
	u16_t num_of_full_packets=0, i;
	num_of_full_packets = (u16_t)(len/fix_len);
	xil_printf("%d Bytes to PC\n\r", len);
	xil_printf("num_of_full_packets=%d\n\r", num_of_full_packets);
	for(i=0; i<num_of_full_packets; i++) { // send full packets
		xil_printf("tcp_sndbuf(tpcb)=%d\n\r", tcp_sndbuf(tpcb));
		if (tcp_sndbuf(tpcb) > fix_len){
			err = tcp_write(tpcb, arg+i*fix_len, fix_len, apiflags);
			xil_printf("%dth full packet sent\n\r", i);
		}
		else{
			xil_printf("no space in tcp_sndbuf\n\r");
		}
		wait_ms(1);
	}
	if (len%fix_len>0){						// send last not full packet
		tcp_write(tpcb, arg+i*fix_len, (u16_t)(len-i*fix_len), apiflags);
		xil_printf("%dth last packet sent\n\r", i+1);
	}
}

