#include <stdio.h>
#include <string.h>
#include <stdlib.h>     /* strtol */
#include <xil_io.h>
#include "xil_printf.h"
#include "xscugic.h"
#include "ps7_init.h"
#include "xparameters.h"
#include "platform.h"
#include "lwip/err.h"
#include "lwip/tcp.h"
#include "_app.h"

//#define LWIP_DISABLE_TCP_SANITY_CHECKS  1
u32 DDR_FC2_dst0=0x10000000, DDR_FC2_dst1=0x10000000, FC2_LEN=80;
u32 DDR_FC1_dst0=0x10000000, DDR_FC1_dst1=0x10000000, FC1_LEN=128;

int transfer_data(){
//	xil_printf("In transfer_data function\n\r");
	return 0;
}

void print_app_header(){
	xil_printf("\n\r\n\r-----lwIP TCP echo server app7 ------\n\r");
	xil_printf("TCP packets sent to port 6001 will be echoed back\n\r");
}

err_t recv_callback(void *arg, struct tcp_pcb *tpcb,
                               struct pbuf *p, err_t err){
//	xil_printf("\n\r\n\rrecv_callback\n\r\n\r");
	u32 send_to_pc=0;
	/* do not read the packet if we are not in ESTABLISHED state */
//	xil_printf("\n\rBefore if (!p)\n\r");
	if (!p){
		tcp_close(tpcb);
		tcp_recv(tpcb, NULL);
		return ERR_OK;
	}
//	xil_printf("After if (!p)\n\r");
	/* indicate that the packet has been received */
	tcp_recved(tpcb, p->len);
//	xil_printf("tcp_recved OK\n\r");
//	xil_printf("len: %d\n\r",p->len);
//	xil_printf("tot_len: %d\n\r",p->tot_len);
//	xil_printf("%s\n\r",p->payload);
	// Cia ideti savo f-ja
	send_to_pc = process_packet(p->payload,p->len,p->tot_len);
//	xil_printf("Packet process done.\n\r");

	/* echo back the payload */
	/* in this case, we assume that the payload is < TCP_SND_BUF */
//	if (tcp_sndbuf(tpcb) > p->len) {
//		err = tcp_write(tpcb, p->payload, p->len, 1);
//		xil_printf("tcp_write OK\n\r");
//	} else
//		xil_printf("no space in tcp_sndbuf\n\r");
	if(send_to_pc==1){
		xil_printf("Send to PC start.\n\r");
//		send_image(tpcb, (void *)DDR_BASE_IMAGE, X*Y*8, 1);
//		err = tcp_write(tpcb, (void *)DDR_BASE2, X*Y*8, 1); // (tpcb, Pointer to mem, Amount of Bytes, 1)
		err = tcp_write(tpcb, (void *)DDR_FC2_dst0, FC2_LEN, 1);
		err = tcp_write(tpcb, (void *)DDR_FC2_dst1, FC2_LEN, 1);
//		err = tcp_write(tpcb, (void *)DDR_FC1_dst0, FC1_LEN, 1);
//		err = tcp_write(tpcb, (void *)DDR_FC1_dst1, FC1_LEN, 1);
		xil_printf("Send to PC done.\n\r");
	}
	/* free the received pbuf */
	pbuf_free(p);
//	xil_printf("pbuf_free OK\n\r\n\r");
	return ERR_OK;
}

err_t accept_callback(void *arg, struct tcp_pcb *newpcb, err_t err){
	static int connection = 1;

	/* set the receive callback for this connection */
//	xil_printf("Before tcp_recv\n\r");
	tcp_recv(newpcb, recv_callback);
//	xil_printf("tcp_recv OK\n\r");
	/* just use an integer number indicating the connection id as the
	   callback argument */
	tcp_arg(newpcb, (void*)(UINTPTR)connection);

	xil_printf("Connection %d\n\r", connection);
	/* increment for subsequent accepted connections */
	connection++;

	return ERR_OK;
}

int start_application(){
	struct tcp_pcb *pcb;
	err_t err;
	unsigned port = 7;

	/* create new TCP PCB structure */
	pcb = tcp_new();
	if (!pcb) {
		xil_printf("Error creating PCB. Out of Memory\n\r");
		return -1;
	}

	/* bind to specified @port */
	err = tcp_bind(pcb, IP_ADDR_ANY, port);
	if (err != ERR_OK) {
		xil_printf("Unable to bind to port %d: err = %d\n\r", port, err);
		return -2;
	}

	/* we do not need any arguments to callback functions */
	tcp_arg(pcb, NULL);

	/* listen for connections */
	pcb = tcp_listen(pcb);
	if (!pcb) {
		xil_printf("Out of memory while tcp_listen\n\r");
		return -3;
	}

	/* specify callback to use for incoming connections */
	tcp_accept(pcb, accept_callback);

	xil_printf("TCP echo server started @ port %d\n\r", port);

	return 0;
}
