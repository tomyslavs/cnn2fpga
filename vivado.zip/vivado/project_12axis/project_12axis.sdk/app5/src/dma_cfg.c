#include "_app.h"


// Interrupt controller
XScuGic InterruptController;
static XScuGic_Config *GicConfig;
u32 global_frame_counter_2_s2mm=0, global_frame_counter_0_mm2s=0;
u32 global_frame_counter_3_s2mm=0, global_frame_counter_1_mm2s=0;

u32 cc_cnt=0, shiftTXd, sizeTXd, sizeTXw1, sizeTXw2, last_layer_idx = 100, timer0=0, timer1=0, timer2=0, timer3=0;
u32 x_max, y_max, ed = 3+3; // extra delay for conv, bn ed=3+2, relu ed=3+3, max pool ed=3+3 | now 3+3 for all | 3+4 with overflow control
extern u32 input_resolution[3];
extern u32 IMG_BASE, NET_BASE, INSTR_BASE, CORE_BASE, FC_W_BASE[5], FC_B_BASE[5], TEMP_BASE, RES_BASE, N_CONV_INSTR, FC1_DATA_BASE;
extern u32 conv_idx, bn_idx, relu_idx, pool_idx, fc_idx, conv_cfgs[20], sum_cfgs[20], conv_and_sum_cfgs[20], all_conv_len, all_fc_w_len, all_fc_b_len;
extern u32 instr0, yx_lim, current_layer_idx, sizeTX, sizeRX, src_0, src_1, dst_0, dst_1;
extern u32 fc1_in_max, fc1_max, fc2_max, fc1_in_mem_updates;
extern u32 DDR_FC2_dst0, DDR_FC2_dst1, FC2_LEN, DDR_FC1_dst0, DDR_FC1_dst1, FC1_LEN;

void arm_enable_mm2s_tready(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_0_BASEADDR, val); // 0/1
}
void arm_delay_conv_valid0_start(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_1_BASEADDR, val); // 20b max
}
void arm_delay_conv_valid1_start(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_2_BASEADDR, val); // 20b max
}
void arm_delay_conv_valid0_done(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_3_BASEADDR, val); // 20b max
}
void arm_delay_conv_valid1_done(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_4_BASEADDR, val); // 20b max
}
void arm_delay_border_pix_deny_start(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_10_BASEADDR, val); // 20b max
}
void arm_x_max(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_11_BASEADDR, val); // x=511 max
}
void arm_y_max(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_12_BASEADDR, val); // y=511 max
}
void arm_B(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_13_BASEADDR, val); // y=511 max
}
void arm_ka(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_14_BASEADDR, val); // y=511 max
}
void arm_be(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_15_BASEADDR, val); // y=511 max
}
void arm_update_weights(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_16_BASEADDR, val); //
}
void arm_enable_filter(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_17_BASEADDR, val); //
}
void arm_xn_or_relu_or_pool(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_18_BASEADDR, val); // 2b
	// 0-relu, 1-pool, 2-xn
}
void arm_update_conv_core_config(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_19_BASEADDR, val); // 1b
}
void arm_merge_xn(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_20_BASEADDR, val); // 1b
}
void arm_fc2_to_ddr(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_21_BASEADDR, val); // 1b
}
void arm_update_fc1_b(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_22_BASEADDR, val); // 1b
}
void arm_update_fc2_b(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_23_BASEADDR, val); // 1b
}
void arm_update_fc1_data(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_24_BASEADDR, val); // 1b
}
void arm_enable_fc1_filter(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_25_BASEADDR, val); // 1b
}
void arm_enable_fc2_filter(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_26_BASEADDR, val); // 1b
}
void arm_enable_fc_out_read_back(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_27_BASEADDR, val); // 1b
}
void arm_ack_done(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_28_BASEADDR, val); // 1b
}
void arm_select_conv_core_config(u32 val){
	Xil_Out32(XPAR_AXI_GPIO_29_BASEADDR, val); // 4b
}
void arm_fc1_in_max(u32 val){ // max 4096 = 64x64 image
	Xil_Out32(XPAR_AXI_GPIO_30_BASEADDR, val-1); // 32b
}
void arm_fc2_max(u32 val){ // max 1024 neurons
	Xil_Out32(XPAR_AXI_GPIO_31_BASEADDR, val-1); // 32b
}
void arm_fc1_max(u32 val){ // max 1024 neurons
	Xil_Out32(XPAR_AXI_GPIO_32_BASEADDR, val-1); // 32b
}
void operation_done(){
	u32 val=0;
	while(val==0)
		val = Xil_In32(XPAR_AXI_GPIO_33_BASEADDR);
}
void wait_for_operation_done_then_response_with_ack(){
	operation_done();
	if (print_enabled==1)
		xil_printf("FPGA operation done ->");
	arm_ack_done(1);
	if (print_enabled==1)
		xil_printf(" ARM ack ->\n\r");
	arm_ack_done(0);
}
void arm_tic(u32 init){ // initial time 31b
	init = 0x80000000 | init;
	Xil_Out32(XPAR_AXI_GPIO_35_BASEADDR, init); // start counter with initial time
}
u32 arm_toc(){
	Xil_Out32(XPAR_AXI_GPIO_35_BASEADDR, 0x00000000); // stop counter, capture time
	return Xil_In32(XPAR_AXI_GPIO_34_BASEADDR); // return time
}
void arm_set_precision(u32 val){ // 0 - 8.8b, 1 - 4.12b
	Xil_Out32(XPAR_AXI_GPIO_36_BASEADDR, val); // 32b
}
void wait_ms(u32 kiek){
	u32 m=0;
	kiek = 0x00014500*kiek; // 0x04500000~1sec // 11A90~1ms
	for (m=0; m<kiek; m++); // wait a bit
}
void wait_us(u32 kiek){
	u32 m=0;
	kiek = 0x00000048*kiek; // 0x04500000~1sec // 0x11A90~1ms // 0x48~1us
	for (m=0; m<kiek; m++); // wait a bit
}
void wait_100ns(u32 kiek){
	u32 m=0;
	kiek = 0x00000007*kiek; // 0x04500000~1sec // 0x11A90~1ms // 0x48~1us // 0x7~0.1us~100ns
	for (m=0; m<kiek; m++); // wait a bit
}
void time_print(u32 timer){
	float time_f;
	int whole, thousandths;
	time_f = (float)timer/100000000;
	whole = time_f;
	thousandths = (time_f-whole)*1000000;
	if(thousandths<10)
		xil_printf("time=%d.00000%1ds\n\r", whole, thousandths);
	else if(thousandths<100)
		xil_printf("time=%d.0000%2ds\n\r", whole, thousandths);
	else if(thousandths<1000)
		xil_printf("time=%d.000%3ds\n\r", whole, thousandths);
	else if(thousandths<10000)
		xil_printf("time=%d.00%4ds\n\r", whole, thousandths);
	else if(thousandths<100000)
		xil_printf("time=%d.0%5ds\n\r", whole, thousandths);
	else
		xil_printf("time=%d.%6ds\n\r", whole, thousandths);
}

void disp_DDR(u32 nuo, u32 length){ // length in bytes
	u32 DataRead3, m, first_run=1;
	for (m=0; m < length>>2; m++){ // 128 - 2cmd | 1024 - 16cmd
		DataRead3 = Xil_In32(nuo+4*m);
		if (m%4==0){
			if (m>>0 < 10){
				if (first_run==1){
					xil_printf("  %d: ",m>>0);
					first_run = 0;
				}
				else
					xil_printf("\n\r  %d: ",m>>0);
			}
			else if (m>>0 < 100)
				xil_printf("\n\r %d: ",m>>0);
			else
				xil_printf("\n\r%d: ",m>>0);
		}
		xil_printf("%08x ",DataRead3);
	}
	xil_printf("\n\r");
}

void FillDDR(u32 addr, u32 length, u32 data){ // length in bytes
	u32 m;
	for (m=0; m < length>>2; m++){
		Xil_Out32((UINTPTR)(addr+4*m), data);
	}
}

int SetUpInterruptSystem(XScuGic *XScuGicInstancePtr){
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler) XScuGic_InterruptHandler, XScuGicInstancePtr);
	Xil_ExceptionEnable();
	return XST_SUCCESS;
}

// HP2 DMA2 s2mm
void InitAXIDMA_2_s2mm(u32 reg_val){
	u32 val;
	val = Xil_In32(XPAR_AXI_DMA_2_BASEADDR + 0x30); // S2MM_DMACR - DMA Control Register
	val = val | reg_val; // 0x1001; // Run - Start DMA operations (0 bit), and enable interrupts IOC_IrqEN (12b)
	Xil_Out32(XPAR_AXI_DMA_2_BASEADDR + 0x30, val);
	val = Xil_In32(XPAR_AXI_DMA_2_BASEADDR + 0x30);
	xil_printf("DMA_2_s2mm Control Register: %x\n\r", val);
}

void StartTransferDMA_2_s2mm(u32 dstAddress, u32 len){
	Xil_Out32(XPAR_AXI_DMA_2_BASEADDR + 0x48, dstAddress); // write destination address to S2MM_DA register, lower 32b address
	Xil_Out32(XPAR_AXI_DMA_2_BASEADDR + 0x58, len); // write length to S2MM_LENGTH register, S2MM Buffer Length (Bytes)
}

void InterruptHandler_2_s2mm(){
	u32 val;
	xil_printf("Interrupt DMA 2 s2mm\n\r");
	// clear interrupt, write to bit no 12 of S2MM_DMASR
	val = Xil_In32(XPAR_AXI_DMA_2_BASEADDR + 0x34);
	val = val | 0x1000;
	Xil_Out32(XPAR_AXI_DMA_2_BASEADDR + 0x34, val); // clear interrupt detected bit IOC_Irq

//	// Data in DDR RAM
//
//	global_frame_counter_2_s2mm++;
//	if (global_frame_counter_2_s2mm <= TOTAL_PACKETS){
//		xil_printf("DMA_2_s2mm frame number: %d\n\r", global_frame_counter_2_s2mm);
////		disp_DDR(0x0a000000,33000);
//		StartTransferDMA_2_s2mm(DDR_BASE2, PACKET_SIZE_RX); // 0x0a000000
//	}
//	else
//		xil_printf("No DMA_2_s2mm transfer since now\n\r");
}

u32 InitInterruptSystem_2_s2mm(u16 DeviceID){
	int Status;
//	XScuGic_Config GicConfig;

	GicConfig = XScuGic_LookupConfig(DeviceID);
	if (NULL == GicConfig){
		return XST_FAILURE;
	}

	Status = XScuGic_CfgInitialize(&InterruptController, GicConfig, GicConfig->CpuBaseAddress);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}

	Status = SetUpInterruptSystem(&InterruptController);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}

	Status = XScuGic_Connect(&InterruptController,
			XPAR_FABRIC_AXI_DMA_2_S2MM_INTROUT_INTR,
			(Xil_ExceptionHandler)InterruptHandler_2_s2mm,
			NULL);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}
	XScuGic_Enable(&InterruptController, XPAR_FABRIC_AXI_DMA_2_S2MM_INTROUT_INTR);

	return XST_SUCCESS;
}

// HP0 DMA0 mm2s
void InitAXIDMA_0_mm2s(u32 reg_val){
	u32 val;
	val = Xil_In32(XPAR_AXI_DMA_0_BASEADDR + 0x00); // MM2S_DMACR - DMA Control Register
	val = val | reg_val; // Run - Start DMA operations (0 bit), and not enable interrupts IOC_IrqEN (12b) = 0x0001
	Xil_Out32(XPAR_AXI_DMA_0_BASEADDR + 0x00, val);
	val = Xil_In32(XPAR_AXI_DMA_0_BASEADDR + 0x00);
	xil_printf("DMA_0_mm2s Control Register: %x\n\r", val);
}

void StartTransferDMA_0_mm2s(u32 dstAddress, u32 len){
	Xil_Out32(XPAR_AXI_DMA_0_BASEADDR + 0x18, dstAddress); // write destination address to MM2S_DA register, lower 32b address
	Xil_Out32(XPAR_AXI_DMA_0_BASEADDR + 0x28, len); // write length to MM2S_LENGTH register, MM2S Buffer Length (Bytes)
}

void InterruptHandler_0_mm2s(){
	u32 val;
	xil_printf("Interrupt DMA 0 mm2s\n\r");
	// clear interrupt, write to bit no 12 of MM2S_DMASR
	val = Xil_In32(XPAR_AXI_DMA_0_BASEADDR + 0x04);
	val = val | 0x1000;
	Xil_Out32(XPAR_AXI_DMA_0_BASEADDR + 0x04, val); // clear interrupt detected bit IOC_Irq

	// Data in PL buffer

//	global_frame_counter_0_mm2s++;
//	if (global_frame_counter_0_mm2s <= TOTAL_PACKETS){
//		xil_printf("DMA_0_mm2s frame number: %d\n\r", global_frame_counter_0_mm2s);
////		disp_DDR(0x0a000000,33000);
//		// New transfer
//		StartTransferDMA_0_mm2s(DDR_BASE+global_frame_counter_0_mm2s*PACKET_SIZE_TX, PACKET_SIZE_TX);
//	}
//	else
//		xil_printf("No DMA_0_mm2s transfer since now\n\r");
//	disp_DDR(DDR_BASE+global_frame_counter_0_mm2s*PACKET_SIZE_TX-4, 4);

//	xil_printf("InterruptHandler StartDMATransfer\n\r");
}

u32 InitInterruptSystem_0_mm2s(u16 DeviceID){
	int Status;
//	XScuGic_Config GicConfig;

	GicConfig = XScuGic_LookupConfig(DeviceID);
	if (NULL == GicConfig){
		return XST_FAILURE;
	}

	Status = XScuGic_CfgInitialize(&InterruptController, GicConfig, GicConfig->CpuBaseAddress);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}

	Status = SetUpInterruptSystem(&InterruptController);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}

	Status = XScuGic_Connect(&InterruptController,
			XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR,
			(Xil_ExceptionHandler)InterruptHandler_0_mm2s,
			NULL);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}
	XScuGic_Enable(&InterruptController, XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR);

	return XST_SUCCESS;
}

// HP3 DMA3 s2mm
void InitAXIDMA_3_s2mm(u32 reg_val){
	u32 val;
	val = Xil_In32(XPAR_AXI_DMA_3_BASEADDR + 0x30); // S2MM_DMACR - DMA Control Register
	val = val | reg_val; // 0x1001; // Run - Start DMA operations (0 bit), and enable interrupts IOC_IrqEN (12b)
	Xil_Out32(XPAR_AXI_DMA_3_BASEADDR + 0x30, val);
	val = Xil_In32(XPAR_AXI_DMA_3_BASEADDR + 0x30);
	xil_printf("DMA_3_s2mm Control Register: %x\n\r", val);
}

void StartTransferDMA_3_s2mm(u32 dstAddress, u32 len){
	Xil_Out32(XPAR_AXI_DMA_3_BASEADDR + 0x48, dstAddress); // write destination address to S2MM_DA register, lower 32b address
	Xil_Out32(XPAR_AXI_DMA_3_BASEADDR + 0x58, len); // write length to S2MM_LENGTH register, S2MM Buffer Length (Bytes)
}

void InterruptHandler_3_s2mm(){
	u32 val;
	xil_printf("Interrupt DMA 3 s2mm\n\r");
	// clear interrupt, write to bit no 12 of S2MM_DMASR
	val = Xil_In32(XPAR_AXI_DMA_3_BASEADDR + 0x34);
	val = val | 0x1000;
	Xil_Out32(XPAR_AXI_DMA_3_BASEADDR + 0x34, val); // clear interrupt detected bit IOC_Irq

//	// Data in DDR RAM
//
//	global_frame_counter_3_s2mm++;
//	if (global_frame_counter_3_s2mm <= TOTAL_PACKETS){
//		xil_printf("DMA_3_s2mm frame number: %d\n\r", global_frame_counter_3_s2mm);
////		disp_DDR(0x0a000000,33000);
//		StartTransferDMA_3_s2mm(DDR_BASE3, PACKET_SIZE_RX); // 0x0a000000
//	}
//	else
//		xil_printf("No DMA_3_s2mm transfer since now\n\r");
}

u32 InitInterruptSystem_3_s2mm(u16 DeviceID){
	int Status;
//	XScuGic_Config GicConfig;

	GicConfig = XScuGic_LookupConfig(DeviceID);
	if (NULL == GicConfig){
		return XST_FAILURE;
	}

	Status = XScuGic_CfgInitialize(&InterruptController, GicConfig, GicConfig->CpuBaseAddress);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}

	Status = SetUpInterruptSystem(&InterruptController);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}

	Status = XScuGic_Connect(&InterruptController,
			XPAR_FABRIC_AXI_DMA_3_S2MM_INTROUT_INTR,
			(Xil_ExceptionHandler)InterruptHandler_3_s2mm,
			NULL);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}
	XScuGic_Enable(&InterruptController, XPAR_FABRIC_AXI_DMA_3_S2MM_INTROUT_INTR);

	return XST_SUCCESS;
}

// HP1 DMA1 mm2s
void InitAXIDMA_1_mm2s(u32 reg_val){
	u32 val;
	val = Xil_In32(XPAR_AXI_DMA_1_BASEADDR + 0x00); // MM2S_DMACR - DMA Control Register
	val = val | reg_val; // Run - Start DMA operations (0 bit), and not enable interrupts IOC_IrqEN (12b) = 0x0001
	Xil_Out32(XPAR_AXI_DMA_1_BASEADDR + 0x00, val);
	val = Xil_In32(XPAR_AXI_DMA_1_BASEADDR + 0x00);
	xil_printf("DMA_1_mm2s Control Register: %x\n\r", val);
}

void StartTransferDMA_1_mm2s(u32 dstAddress, u32 len){
	Xil_Out32(XPAR_AXI_DMA_1_BASEADDR + 0x18, dstAddress); // write destination address to MM2S_DA register, lower 32b address
	Xil_Out32(XPAR_AXI_DMA_1_BASEADDR + 0x28, len); // write length to MM2S_LENGTH register, MM2S Buffer Length (Bytes)
}

void InterruptHandler_1_mm2s(){
	u32 val;
	xil_printf("Interrupt DMA 1 mm2s\n\r");
	// clear interrupt, write to bit no 12 of MM2S_DMASR
	val = Xil_In32(XPAR_AXI_DMA_1_BASEADDR + 0x04);
	val = val | 0x1000;
	Xil_Out32(XPAR_AXI_DMA_1_BASEADDR + 0x04, val); // clear interrupt detected bit IOC_Irq

	// Data in PL buffer

//	global_frame_counter_1_mm2s++;
//	if (global_frame_counter_1_mm2s <= TOTAL_PACKETS){
//		xil_printf("DMA_1_mm2s frame number: %d\n\r", global_frame_counter_1_mm2s);
////		disp_DDR(0x0a000000,33000);
//		// New transfer
//		StartTransferDMA_1_mm2s(DDR_BASE+global_frame_counter_1_mm2s*PACKET_SIZE_TX, PACKET_SIZE_TX);
//	}
//	else
//		xil_printf("No DMA_1_mm2s transfer since now\n\r");
//	disp_DDR(DDR_BASE+global_frame_counter_1_mm2s*PACKET_SIZE_TX-4, 4);
//
////	xil_printf("InterruptHandler StartDMATransfer\n\r");
}

u32 InitInterruptSystem_1_mm2s(u16 DeviceID){
	int Status;
//	XScuGic_Config GicConfig;

	GicConfig = XScuGic_LookupConfig(DeviceID);
	if (NULL == GicConfig){
		return XST_FAILURE;
	}

	Status = XScuGic_CfgInitialize(&InterruptController, GicConfig, GicConfig->CpuBaseAddress);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}

	Status = SetUpInterruptSystem(&InterruptController);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}

	Status = XScuGic_Connect(&InterruptController,
			XPAR_FABRIC_AXI_DMA_1_MM2S_INTROUT_INTR,
			(Xil_ExceptionHandler)InterruptHandler_1_mm2s,
			NULL);
	if (Status != XST_SUCCESS){
		return XST_FAILURE;
	}
	XScuGic_Enable(&InterruptController, XPAR_FABRIC_AXI_DMA_1_MM2S_INTROUT_INTR);

	return XST_SUCCESS;
}


void InitAXIDMA(){
	xil_printf("\n\r");
	ps7_post_config();
	// Clean DDR memory
	FillDDR(DDR_BASE, DDR_RANGE, 0x00000000);
	Xil_DCacheFlushRange(DDR_BASE, DDR_RANGE);
	// Set initial flags
	arm_enable_mm2s_tready(0);
	arm_update_weights(0);
	arm_enable_filter(0);
	arm_enable_fc_out_read_back(0);
	arm_update_fc1_data(0);
	arm_enable_fc1_filter(0);
	arm_enable_fc2_filter(0);
	arm_fc2_to_ddr(0);

	// Init DMA
	xil_printf("Init AXI DMA 0 mm2s\n\r");
	InitAXIDMA_0_mm2s(0x0001);
	xil_printf("Init AXI DMA 1 mm2s\n\r");
	InitAXIDMA_1_mm2s(0x0001);
	xil_printf("Init AXI DMA 2 s2mm\n\r");
	InitAXIDMA_2_s2mm(0x0001);
	xil_printf("Init AXI DMA 3 s2mm\n\r");
	InitAXIDMA_3_s2mm(0x0001);

//	xil_printf("Set interrupt handling DMA 0 mm2s\n\r");
//	InitInterruptSystem_0_mm2s(XPAR_PS7_SCUGIC_0_DEVICE_ID);
//	xil_printf("Set interrupt handling DMA 1 mm2s\n\r");
//	InitInterruptSystem_1_mm2s(XPAR_PS7_SCUGIC_0_DEVICE_ID);
//	xil_printf("Set interrupt handling DMA 2 s2mm\n\r");
//	InitInterruptSystem_2_s2mm(XPAR_PS7_SCUGIC_0_DEVICE_ID);
//	xil_printf("Set interrupt handling DMA 3 s2mm\n\r");
//	InitInterruptSystem_3_s2mm(XPAR_PS7_SCUGIC_0_DEVICE_ID);

	x_max = X-1;
	y_max = Y-1;
	arm_x_max(x_max);
	arm_y_max(y_max);
	arm_delay_conv_valid0_start((ed+12+x_max)*2); // valid conv response +8 clk (add to all delays) // 0+8+512+1 center of 3x3 conv
	arm_delay_conv_valid1_start((ed+12+x_max)*2);
	arm_delay_border_pix_deny_start((6+x_max)*2);
	arm_delay_conv_valid0_done((ed+12+x_max)*2+1); // 1+8+512+1
	arm_delay_conv_valid1_done((ed+12+x_max)*2+1);
	arm_xn_or_relu_or_pool(1); // 0-relu, 1-pool, 2-xn
	xil_printf("InitAXIDMA done\n\r");
}

void set_fc_b(u32 layer, u32 src, u32 size){
	if (layer==1)
		arm_update_fc1_b(1);
	else if (layer==2)
		arm_update_fc2_b(1);
	StartTransferDMA_0_mm2s(src, size);
	wait_100ns(1);//wait_ms(10);//
	arm_enable_mm2s_tready(1);
	wait_for_operation_done_then_response_with_ack();
	arm_enable_mm2s_tready(0);
	if (layer==1)
		arm_update_fc1_b(0);
	else if (layer==2)
		arm_update_fc2_b(0);
}

void arm_set_conv_timming(){
	if (current_layer_idx!=last_layer_idx){
		x_max = (yx_lim & 0x0000FFFF)-1; // low 16b, eg. [0-63]
		y_max = ((yx_lim>>16) & 0x0000FFFF)-1; // hi 16b
		arm_x_max(x_max); //wait_100ns(1);
		arm_y_max(y_max); //wait_100ns(1);
		arm_delay_conv_valid0_start((ed+12+x_max)*2); //wait_100ns(1); // valid conv response +8 clk (add to all delays) // 0+8+512+1 center of 3x3 conv
		arm_delay_conv_valid1_start((ed+12+x_max)*2); //wait_100ns(1);
		arm_delay_border_pix_deny_start((6+x_max)*2); //wait_100ns(1);
		arm_delay_conv_valid0_done((ed+12+x_max)*2+1); //wait_100ns(1); // 1+8+512+1
		arm_delay_conv_valid1_done((ed+12+x_max)*2+1); //wait_100ns(1);
		if (print_enabled==1)
			xil_printf("Conv Layer %d, y_lim=%d, x_lim=%d\n\r", current_layer_idx, y_max, x_max);
	}
	last_layer_idx = current_layer_idx;
}

void run_conv_core(u32 conv_or_sum, u32 xn_relu_pool){
	arm_set_conv_timming(); // update timming if conv layer changes
//	cc_cnt=0; // core 0
	if (print_enabled==1)
		xil_printf("conv_or_sum=%d, xn_relu_pool=%d\n\r",conv_or_sum,xn_relu_pool);
	arm_merge_xn(conv_or_sum);				// 0-normal conv, 1-sum (conv core works like adder)
	arm_xn_or_relu_or_pool(xn_relu_pool);	// xn 2, relu 0, pool 1
	if (conv_or_sum==0){
		if (print_enabled==1)
			xil_printf("arm_select_conv_core_config=%d\n\r",cc_cnt);
		arm_select_conv_core_config(cc_cnt);//wait_100ns(1);	// 0-14 conv
		if (cc_cnt<14)
			cc_cnt++; // increment conv core counter
		else
			cc_cnt=0;
	}
	else{
		if (print_enabled==1)
			xil_printf("arm_select_conv_core_config=%d\n\r",15);
		arm_select_conv_core_config(15);	// 15 sum
	}
//	wait_ms(1);
//	arm_update_conv_core_config(1); wait_100ns(1); arm_update_conv_core_config(0); // short pulse, BRAM->Core
	arm_update_conv_core_config(1);
//	wait_ms(1);
	wait_for_operation_done_then_response_with_ack(); //wait_100ns(1);
	arm_update_conv_core_config(0); // short pulse, BRAM->Core
//	wait_ms(1);
	if (print_enabled==1){
		xil_printf("src_0=0x%08x, src_1=0x%08x\n\r", src_0, src_1);
		xil_printf("dst_0=0x%08x, dst_1=0x%08x\n\r", dst_0, dst_1);
		xil_printf("sizeTX=0x%08x, sizeRX=0x%08x\n\r",sizeTX,sizeRX);
	}
	if (conv_or_sum==0) // if conv
		StartTransferDMA_3_s2mm(dst_1, sizeRX); // sizeRX // 0x00008000
	StartTransferDMA_2_s2mm(dst_0, sizeRX); // sizeRX // 0x00008000
	StartTransferDMA_1_mm2s(src_1, sizeTX); // sizeTX // 0x00008000
	StartTransferDMA_0_mm2s(src_0, sizeTX); // sizeTX // 0x00008000

	wait_100ns(1);
//	arm_merge_xn(conv_or_sum);				// 0-normal conv, 1-sum (conv core works like adder)
	arm_enable_filter(1); arm_enable_mm2s_tready(1);
	wait_for_operation_done_then_response_with_ack();
	arm_enable_filter(0); arm_enable_mm2s_tready(0);
	// Flush data in DDR memory
//	Xil_DCacheFlushRange(dst_0,sizeRX); wait_ms(1); Xil_DCacheInvalidateRange(dst_0,sizeRX); wait_ms(100);
//	if (conv_or_sum==0){ // if conv
//		Xil_DCacheFlushRange(dst_1,sizeRX); wait_ms(1); Xil_DCacheInvalidateRange(dst_1,sizeRX); wait_ms(100);
//	}

/////////////////////////////////////////////////////////////////
//// test works
//	StartTransferDMA_0_mm2s(src_0, 0x00008000);
//	StartTransferDMA_1_mm2s(src_1, 0x00008000);
//	StartTransferDMA_2_s2mm(dst_0, 0x00008000);
//	StartTransferDMA_3_s2mm(dst_1, 0x00008000);
//	arm_enable_filter(1);
//	wait_for_operation_done_then_response_with_ack();//wait_ms(10);
//	arm_enable_filter(0);
}

void run_instruction(){
	switch(instr0){
		case 0x10 : // update conv B,k,b
			cc_cnt=0;
			arm_select_conv_core_config(cc_cnt); //0-14 conv, 15-sum
			arm_enable_mm2s_tready(1); // call before arm_update_weights!
			arm_update_weights(1); wait_100ns(1); arm_update_weights(0); // short pulse, DDR->BRAM
			StartTransferDMA_0_mm2s(src_0, sizeTX);
			wait_for_operation_done_then_response_with_ack();
			arm_enable_mm2s_tready(0); // arm_update_weights(0);
			break;
		case 0x01 : // conv+bn
			run_conv_core(0,2);
			break;
		case 0x02 : // conv+bn
			run_conv_core(0,2);
			break;
		case 0x03 : // conv+bn+relu
			run_conv_core(0,0);
			break;
		case 0x04 : // conv+bn+relu+pool
			run_conv_core(0,1);
			break;
		case 0x12 : // sum+bn
			run_conv_core(1,2);
			break;
		case 0x13 : // sum+relu
			run_conv_core(1,0);
			break;
		case 0x14 : // sum+relu+pool
			run_conv_core(1,1);
			break;
		default :
			xil_printf("Not valid instr0\n\r");
	}
}

void call_cnn(){
	u32 max_m00_cnt,max_m01_cnt,max_s00_cnt, max_s01_cnt;
	u32 i;
	arm_set_precision(1); // 0 - 4.12bit | 1 - 6.10bit
	arm_fc1_in_max(fc1_in_max);	// single input CH size at FC1 layer
	arm_fc1_max(fc1_max);		// number of neurons in FC1
	arm_fc2_max(fc2_max);		// number of neurons in FC2 // fc1_max - reikalingas FC1 siunciant i DDR
	set_fc_b(1, FC_B_BASE[0], 2*fc1_max); // set fc1 b, 2B/sample
	set_fc_b(2, FC_B_BASE[1], 2*fc2_max); // set fc2 b, 2B/sample
	if (print_enabled==1)
		xil_printf("set_fc_b done.\n\r");
	// rewrite DDR_RANGE
//	FillDDR(DDR_BASE, DDR_RANGE, 0x01000100);
//	Xil_DCacheFlushRange(IMG_BASE, DDR_RANGE);

//	FillDDR(DDR_BASE+DDR_RANGE, DDR_RANGE, 0x00000000);
//	Xil_DCacheFlushRange(DDR_BASE+DDR_RANGE, DDR_RANGE);
//
//	FillDDR(DDR_BASE+DDR_RANGE+0*2*fc1_in_max, 2*fc1_in_max, 0x00100010); // fill CH3 only
//	Xil_DCacheFlushRange(DDR_BASE+DDR_RANGE+0*2*fc1_in_max, 2*fc1_in_max);

//	Xil_DCacheFlushRange(DDR_BASE, DDR_RANGE);
	// Fill Img mem
//	FillDDR(IMG_BASE, input_resolution[0]*input_resolution[1]*8*2, 0x01000100);
//	Xil_DCacheFlushRange(IMG_BASE, input_resolution[0]*input_resolution[1]*8*2);
//	FillDDR(IMG_BASE, 0x00600000, 0x01000100);
//	Xil_DCacheFlushRange(IMG_BASE, 0x00600000); // wait_ms(100);

//	wait_ms(10);
	// Fill Core mem
//	FillDDR(CORE_BASE-512, 512*3, 0x01000100);
//	Xil_DCacheFlushRange(CORE_BASE-512, 512*3);

//	wait_ms(10);
	// FC1_DATA_BASE mem
//	FillDDR(FC1_DATA_BASE, 512, 0xFFFFFFFF);
//	Xil_DCacheFlushRange(FC1_DATA_BASE, 512); wait_ms(100);
//	Xil_DCacheInvalidateRange(FC1_DATA_BASE,512); wait_ms(100);

//	wait_ms(10);
//	if (print_enabled==1){
		xil_printf("IMG_BASE\n\r");
		disp_DDR(IMG_BASE, 64);

		xil_printf("IMG_ZERO\n\r");
		disp_DDR(IMG_BASE+0x00400000, 64);

		xil_printf("NET_BASE\n\r");
		disp_DDR(NET_BASE, 64);

		xil_printf("INSTR_BASE\n\r");
		disp_DDR(INSTR_BASE, 64);

		xil_printf("CORE_BASE\n\r");
		disp_DDR(CORE_BASE, 64*8); // 1filter=64B, 8filters, 16configs: 64*8*16

		xil_printf("FC_W_BASE[0]=0x%08x\n\r", FC_W_BASE[0]);
		disp_DDR(FC_W_BASE[0], 64);

		xil_printf("FC_W_BASE[1]=0x%08x\n\r", FC_W_BASE[1]);
		disp_DDR(FC_W_BASE[1], 64);

		xil_printf("FC_B_BASE[0]=0x%08x\n\r", FC_B_BASE[0]);
		disp_DDR(FC_B_BASE[0], 64*2);

		xil_printf("FC_B_BASE[1]=0x%08x\n\r", FC_B_BASE[1]);
		disp_DDR(FC_B_BASE[1], 64*2);

	//	xil_printf("FC1_DATA_BASE\n\r");
	//	disp_DDR(FC1_DATA_BASE, 128);
//	}
	wait_ms(500);
	arm_tic(0); // start hardware counter
	// Conv layers
	cc_cnt=0; // reset conv core cnt
	for(i=0;i<N_CONV_INSTR;i++){ // loop over all conv layer instructions (it covers core mem update, conv, sum instr.)
		// Read instruction
		read_instruction(i);
		if (print_enabled==1){
			xil_printf("\n\rinstr: 0x%08x, 0x%08x, 0x%08x, 0x%08x, 0x%08x, 0x%08x, 0x%08x, 0x%08x\n\r",instr0,yx_lim,sizeTX,sizeRX,src_0,src_1,dst_0,dst_1);
		}
//		xil_printf("i=%d",i);
		// Execute instruction
		run_instruction();
//		if(i==0)
//			run_instruction(); // core cfg
//		else if(i==6){ // sum core: 5,6
////		else if(i<5){ // conv core: 1,2,3,4
//			FillDDR(src_0, sizeTX, 0x00020002);	Xil_DCacheFlushRange(src_0, sizeTX);
//			FillDDR(src_1, sizeTX, 0x00010001);	Xil_DCacheFlushRange(src_1, sizeTX);
//			run_instruction();
//		}
//		wait_us(1);
		Xil_DCacheFlushRange(dst_0, sizeRX);
		Xil_DCacheFlushRange(dst_1, sizeRX);
//		wait_us(1);
//		xil_printf("Conv %d done.\n\r",i);
//		xil_printf("dst_0=0x%08x\n\r",dst_0);
//		disp_DDR(dst_0,64);
//
//		xil_printf("dst_1=0x%08x\n\r",dst_1);
//		disp_DDR(dst_1,64);
//
//		xil_printf("src_0=0x%08x\n\r",src_0);
//		disp_DDR(src_0,64);
//
//		xil_printf("src_1=0x%08x\n\r",src_1);
//		disp_DDR(src_1,64);
//
//		xil_printf("\n\r");
//		wait_ms(500);
	}
	timer0 = arm_toc(); // stop hardware counter. time_print(timer);
//	xil_printf("Conv  "); time_print(timer0);
//	Xil_DCacheFlushRange(DDR_BASE, DDR_RANGE);
	if (print_enabled==1){
		xil_printf("Conv done.\n\r");
		xil_printf("dst_0=0x%08x\n\r",dst_0);
		disp_DDR(dst_0,64);

		xil_printf("dst_1=0x%08x\n\r",dst_1);
		disp_DDR(dst_1,64);

		xil_printf("src_0=0x%08x\n\r",src_0);
		disp_DDR(src_0,64);

		xil_printf("src_1=0x%08x\n\r",src_1);
		disp_DDR(src_1,64);
	}
//	xil_printf("L0 c0 dst_0\n\r"); disp_DDR(0x10985000,64);
//	xil_printf("L0 c0 dst_1\n\r"); disp_DDR(0x1098D000,64);
//	xil_printf("L0 c1 dst_0\n\r"); disp_DDR(0x10995000,64);
//	xil_printf("L0 c1 dst_1\n\r"); disp_DDR(0x1099D000,64);
//	xil_printf("L1 c0 dst_0\n\r"); disp_DDR(0x109A9000,64);
//	xil_printf("L1 c0 dst_1\n\r"); disp_DDR(0x109B1000,64);
//	xil_printf("L1 c1 dst_0\n\r"); disp_DDR(0x109B9000,64);
//	xil_printf("L1 c1 dst_1\n\r"); disp_DDR(0x109C1000,64);

//	xil_printf("dst_1=0x%08x\n\r",dst_1);
//	disp_DDR(dst_1,64);
///////////////////////////////////////////////////////////////////////
	// FC layers
	arm_tic(0); // start hardware counter
//	arm_fc1_in_max(fc1_in_max);	// single input CH size at FC1 layer
//	arm_fc1_max(fc1_max);		// number of neurons in FC1
//	arm_fc2_max(fc1_max);		// number of neurons in FC2 // fc1_max - reikalingas FC1 siunciant i DDR
//	set_fc_b(1, FC_B_BASE[0], 2*fc1_max); // set fc1 b, 2B/sample
//	set_fc_b(2, FC_B_BASE[1], 2*fc2_max); // set fc2 b, 2B/sample
//	if (print_enabled==1)
//		xil_printf("set_fc_b done.\n\r");
	// run fc1
	arm_enable_fc_out_read_back(0);
	sizeTXd = 2*4*fc1_in_max; 	// input resolution x 2B x 4Channels
	if (sizeTXd<4096)
		shiftTXd = 4096;
	else
		shiftTXd = sizeTXd;
	sizeTXw1 = fc1_in_max*(fc1_max>>1)*8*2; // input resolution x half of neurons x 8CH x 2B
	for(i=0;i<fc1_in_mem_updates;i++){ 		// loop over FC1 layer data mem updates
		// renew address
//		src_0 = FC1_DATA_BASE+sizeTXd*(2*i+0); // DDR_BASE; //
//		src_1 = FC1_DATA_BASE+sizeTXd*(2*i+1); // DDR_BASE; //
		src_0 = FC1_DATA_BASE+shiftTXd*(2*i+0); //xil_printf("src_0=0x%08x\n\r",src_0);
		src_1 = FC1_DATA_BASE+shiftTXd*(2*i+1); //xil_printf("src_1=0x%08x\n\r",src_1);
//		src_0 = FC1_DATA_BASE;
//		src_1 = FC1_DATA_BASE+4096;

		// rewrite fc1 input data in DDR
//		FillDDR(src_0, sizeTXd, 0x00100010);
//		FillDDR(src_1, sizeTXd, 0x00100010);
//		Xil_DCacheFlushRange(src_0, sizeTXd);
//		Xil_DCacheFlushRange(src_1, sizeTXd);

		// stream of input data
		arm_update_fc1_data(1);
		StartTransferDMA_1_mm2s(src_1, sizeTXd);
		StartTransferDMA_0_mm2s(src_0, sizeTXd);
		wait_100ns(3);
		arm_enable_mm2s_tready(1);
		wait_for_operation_done_then_response_with_ack();
		arm_enable_mm2s_tready(0); arm_update_fc1_data(0);

		// renew address
		src_0 = FC_W_BASE[0]+sizeTXw1*(2*i+0); // DDR_BASE; //
		src_1 = FC_W_BASE[0]+sizeTXw1*(2*i+1); // DDR_BASE; //

		// rewrite fc1 w in DDR
//		FillDDR(src_0, sizeTXw1, 0x00100010);
//		FillDDR(src_1, sizeTXw1, 0x00100010);
//		Xil_DCacheFlushRange(src_0, sizeTXw1);
//		Xil_DCacheFlushRange(src_1, sizeTXw1);

		// stream weights
		arm_enable_fc1_filter(1);
		StartTransferDMA_1_mm2s(src_1, sizeTXw1);
		StartTransferDMA_0_mm2s(src_0, sizeTXw1);
		wait_100ns(3);
		arm_enable_mm2s_tready(1);
		wait_for_operation_done_then_response_with_ack();
		arm_enable_mm2s_tready(0); arm_enable_fc1_filter(0);

		arm_enable_fc_out_read_back(1);
		if (print_enabled==1)
			xil_printf("fc1_in_mem_update=%d\r\n",i);
	}
	arm_enable_fc_out_read_back(0);
	timer1 = arm_toc(); // stop hardware counter. time_print(timer);
//	xil_printf("FC1   "); time_print(timer1);
	if (print_enabled==1)
		xil_printf("FC1 done.\n\r");
/////////////////////////////////////////////////////////////////////
	// fc1 to DDR, hangs-up if FC1=32 neurons
	if (FC1_to_DDR_enabled==1){
		arm_enable_fc1_filter(1);
		sizeRX = fc1_max; // e.g. 80 neurons * 2B/2DMA = 80 Bytes
		dst_0 = RES_BASE;
		dst_1 = RES_BASE+4096*4; // max 4096B = 2048x16b = 512neurons x 4CH // +sizeRX;
		StartTransferDMA_2_s2mm(dst_0, sizeRX);
		StartTransferDMA_3_s2mm(dst_1, sizeRX);
		wait_ms(10);
		arm_fc2_to_ddr(1); //wait_100ns(1); arm_fc2_to_ddr(0); // short pulse, same cmd for fc1 and fc2
		wait_for_operation_done_then_response_with_ack();
		arm_fc2_to_ddr(0);
		arm_enable_fc1_filter(0);
		xil_printf("FC1 in DDR.\n\r");

		Xil_DCacheFlushRange(dst_0, sizeRX); Xil_DCacheFlushRange(dst_1, sizeRX); // xil_printf("DCacheFlushRange() OK.\r\n");
		xil_printf("\n\rFC1 results:\n\r");
		xil_printf("dst_0=0x%08x\r\n",dst_0);
		disp_DDR(dst_0, sizeRX);
		xil_printf("dst_1=0x%08x\r\n",dst_1);
		disp_DDR(dst_1, sizeRX);
		// FC1 destination and length for tcp_write function in recv_callback (echo.c)
		DDR_FC1_dst0 = dst_0; DDR_FC1_dst1 = dst_1; FC1_LEN = fc1_max;
		wait_ms(1000);
	}
///////////////////////////////////////////////////////////////////
	// run fc2
	arm_tic(0); // start hardware counter
	arm_fc2_max(fc2_max);		// number of neurons in FC2
	sizeTXw2 = fc1_max*(fc2_max>>1)*2; // input resolution of 2CH x half of neurons x 2B
	// renew address
	src_0 = FC_W_BASE[1];			// DDR_BASE; //
	src_1 = FC_W_BASE[1]+sizeTXw2;	// DDR_BASE; //
	// stream weights
	arm_enable_fc2_filter(1);
	StartTransferDMA_1_mm2s(src_1, sizeTXw2);
	StartTransferDMA_0_mm2s(src_0, sizeTXw2);
	wait_100ns(3);
	arm_enable_mm2s_tready(1);
	wait_for_operation_done_then_response_with_ack();
	arm_enable_mm2s_tready(0); arm_enable_fc2_filter(0);
	timer2 = arm_toc(); // stop hardware counter. time_print(timer);
	if (print_enabled==1)
		xil_printf("FC2 done.\n\r");
	xil_printf("Conv  "); time_print(timer0);
	xil_printf("FC1   "); time_print(timer1);
	xil_printf("FC2   "); time_print(timer2);
	xil_printf("Total "); time_print(timer0+timer1+timer2);
/////////////////////////////////////////////////////////////////////
	// fc2 to DDR
	arm_enable_fc2_filter(1);
	sizeRX = fc2_max; // e.g. 80 neurons * 2B/2DMA = 80 Bytes
	dst_0 = RES_BASE+4096*4*2;
	dst_1 = RES_BASE+4096*4*3; // max 4096B = 2048x16b=512neurons x 4CH // +sizeRX;
	StartTransferDMA_2_s2mm(dst_0, sizeRX);
	StartTransferDMA_3_s2mm(dst_1, sizeRX);
	wait_ms(10);
	arm_fc2_to_ddr(1); //wait_100ns(1); arm_fc2_to_ddr(0); // short pulse, same cmd for fc1 and fc2
	wait_for_operation_done_then_response_with_ack();
	arm_fc2_to_ddr(0);
	arm_enable_fc2_filter(0);
	if (print_enabled==1)
		xil_printf("FC2 in DDR.\n\r");
	Xil_DCacheFlushRange(dst_0, sizeRX); Xil_DCacheFlushRange(dst_1, sizeRX);
	if (print_enabled==1)
		xil_printf("DCacheFlushRange() OK.\r\n");
	xil_printf("\n\rFC2 results:\n\r");
	xil_printf("dst_0=0x%08x\r\n",dst_0);
	disp_DDR(dst_0, sizeRX);
	xil_printf("dst_1=0x%08x\r\n",dst_1);
	disp_DDR(dst_1, sizeRX);
	last_layer_idx = 100; // reset for next run, any but not zero
	// FC2 destination and length for tcp_write function in recv_callback (echo.c)
	DDR_FC2_dst0 = dst_0; DDR_FC2_dst1 = dst_1; FC2_LEN = fc2_max;
/////////////////////////////////////////////////////////////////////
	// DMA stream continuous check
	max_m00_cnt = Xil_In32(XPAR_AXI_GPIO_6_BASEADDR);
	max_m01_cnt = Xil_In32(XPAR_AXI_GPIO_7_BASEADDR);
	max_s00_cnt = Xil_In32(XPAR_AXI_GPIO_8_BASEADDR);
	max_s01_cnt = Xil_In32(XPAR_AXI_GPIO_9_BASEADDR);
	xil_printf("continuous cnt: %x %x %x %x\n\r",max_m00_cnt,max_m01_cnt,max_s00_cnt, max_s01_cnt);
}

